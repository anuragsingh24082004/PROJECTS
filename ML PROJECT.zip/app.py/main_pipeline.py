# main_pipeline.py

import pandas as pd
import numpy as np
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import StandardScaler
from sklearn.ensemble import RandomForestRegressor
from sklearn.metrics import mean_squared_error, mean_absolute_error, r2_score
import joblib

coin1 = pd.read_csv("coin 1.csv")
coin2 = pd.read_csv("coin 2.csv")
coin = pd.concat([coin1, coin2], ignore_index=True)
coin['date'] = pd.to_datetime(coin['date'])
coin = coin.sort_values(by=['symbol', 'date']).reset_index(drop=True)

coin['price'] = pd.to_numeric(coin['price'], errors='coerce')
coin['24h_volume'] = pd.to_numeric(coin['24h_volume'], errors='coerce')
coin['mkt_cap'] = pd.to_numeric(coin['mkt_cap'], errors='coerce')

coin['returns_1d'] = coin.groupby('symbol')['price'].pct_change(periods=1)
coin['price_std3'] = coin.groupby('symbol')['price'].transform(lambda x: x.rolling(window=2, min_periods=1).std())
coin['volume_ma2'] = coin.groupby('symbol')['24h_volume'].transform(lambda x: x.rolling(window=2, min_periods=1).mean())
coin['volume_std2'] = coin.groupby('symbol')['24h_volume'].transform(lambda x: x.rolling(window=2, min_periods=1).std())
coin['liquidity_ratio'] = coin['24h_volume'] / (coin['price_std3'] + 1e-6)
coin['volatility_score'] = coin['price_std3'] * coin['volume_std2']

coin_cleaned = coin.dropna(subset=[
    'returns_1d', 'price_std3', 'volume_ma2', 'volume_std2', 'liquidity_ratio', 'volatility_score'
])

features = ['returns_1d', 'price_std3', 'volume_ma2', 'volume_std2', 'volatility_score']
target = 'liquidity_ratio'

X = coin_cleaned[features]
y = coin_cleaned[target]

scaler = StandardScaler()
X_scaled = scaler.fit_transform(X)
X_train, X_test, y_train, y_test = train_test_split(X_scaled, y, test_size=0.2, random_state=42)

model = RandomForestRegressor(n_estimators=100, random_state=42)
model.fit(X_train, y_train)

y_pred = model.predict(X_test)
print("RMSE:", np.sqrt(mean_squared_error(y_test, y_pred)))
print("MAE:", mean_absolute_error(y_test, y_pred))
print("R2 Score:", r2_score(y_test, y_pred))

joblib.dump(model, "liquidity_model.pkl")
joblib.dump(scaler, "scaler.pkl")
coin_cleaned.to_pickle("cleaned_data.pkl")

