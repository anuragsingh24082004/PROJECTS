# app.py

import streamlit as st
import pandas as pd
import joblib

st.title("Cryptocurrency Liquidity Prediction App")

uploaded_file = st.file_uploader("Upload a cryptocurrency CSV file", type=["csv"])
if uploaded_file:
    df = pd.read_csv(uploaded_file)
    st.write("Data Preview:", df.head())

    df['price'] = pd.to_numeric(df['price'], errors='coerce')
    df['24h_volume'] = pd.to_numeric(df['24h_volume'], errors='coerce')

    df['returns_1d'] = df.groupby('symbol')['price'].pct_change(periods=1)
    df['price_std3'] = df.groupby('symbol')['price'].transform(lambda x: x.rolling(window=2, min_periods=1).std())
    df['volume_ma2'] = df.groupby('symbol')['24h_volume'].transform(lambda x: x.rolling(window=2, min_periods=1).mean())
    df['volume_std2'] = df.groupby('symbol')['24h_volume'].transform(lambda x: x.rolling(window=2, min_periods=1).std())
    df['volatility_score'] = df['price_std3'] * df['volume_std2']
    df['liquidity_ratio'] = df['24h_volume'] / (df['price_std3'] + 1e-6)

    df = df.dropna(subset=['returns_1d', 'price_std3', 'volume_ma2', 'volume_std2', 'volatility_score'])

    features = ['returns_1d', 'price_std3', 'volume_ma2', 'volume_std2', 'volatility_score']
    X = df[features]

    scaler = joblib.load("scaler.pkl")
    model = joblib.load("liquidity_model.pkl")
    X_scaled = scaler.transform(X)

    predictions = model.predict(X_scaled)
    df['Predicted Liquidity'] = predictions

    st.subheader("Predictions")
    st.write(df[['symbol', 'date', 'Predicted Liquidity']])

    st.download_button("Download Predictions", df.to_csv(index=False), file_name="predictions.csv")
